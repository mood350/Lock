from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Ingenieur, Categorie, MembreProjet, Projet
from .forms import IngenieurForm, CategorieForm, CustomUserCreationForm, ProjetForm
from django.db.models import Count
from .models import Ingenieur, Projet, Categorie


def categorie(request):
    if request.method == 'POST':
        form = CategorieForm(request.POST,request.FILES)
        if form.is_valid():
            cat = form.save()
            return redirect('categories')
        else:
            print(form.errors)
            
    else: 
        form =CategorieForm()
    return render(request, 'categorie.html', {'form': form})


def categories(request):
    categorie = Categorie.objects.all()
    return render(request, 'categories.html', {'categ': categorie})


def modifyCategorie(request,id):
    
    categorie= Categorie.objects.get(id=id)
    form = CategorieForm(instance=categorie)
    if request.method == 'POST':
        form = CategorieForm(request.POST,instance=categorie )
        if form.is_valid():
            form.save()
        return redirect ('categories')

    return render (request, 'modif.html', {'form':form, 'Categorie':Categorie})


def deleteCategorie(request,id):
    categorie = Categorie.objects.get(id=id)
    categorie.delete()
    return redirect ('categories')
    
def ajout_Ingenieur(request):
    if request.method == 'POST':
        form = IngenieurForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Ingenieur')  # Vérifie que le nom est exactement celui défini dans urls.py
    else:
        form = IngenieurForm()
    return render(request, 'ingenieur.html', {'form': form})


def liste_ingenieurs(request):
    ingenieurs_list = Ingenieur.objects.all()
    return render(request, 'Ingenieurs.html', {'Ingenieurs': ingenieurs_list})

def modifyIngenieur(request,id):  
    ingenieur= Ingenieur.objects.get(id=id)
    form = IngenieurForm(instance=ingenieur)
    if request.method == 'POST':
        form = IngenieurForm(request.POST,instance=ingenieur )
        if form.is_valid():
            form.save()
        return redirect ('liste_ingenieurs')
    return render (request, 'modi_Ingenieur.html', {'form':form, 'Ingenieur':ingenieur})

def inscription(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('connexion')
    else:
        form = CustomUserCreationForm()
    return render(request, 'inscription.html', {'form': form})

def connexion(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('acceuil')
        else:
            messages.error(request, 'Nom d\'utilisateur ou mot de passe incorrect.')
    return render(request, 'connexion.html')

def deleteIngenieur(request,id):
    ingenieur = Ingenieur.objects.get(id=id)
    ingenieur.delete()
    return redirect ('Ingenieurs')


def Accueil(request):
    return render(request, 'index.html')


def Dashboard(request):
    projet = Projet.objects.all().count()
    ingenieur = Ingenieur.objects.all().count()
    contains = { 'projet': projet, 'ingenieur':ingenieur }
    return render(request, 'dashbore.html', contains)


def deconnexion(request):
    logout(request)
    return redirect('connexion')


def listeProjet(request):
    projet = Projet.objects.all()
    ings = Ingenieur.objects.all()
    return render(request, 'list_projects.html', {'projets':projet, 'ings':ings})

def creer_projet(request):
    membres =  Ingenieur.objects.all()
    if request.method == 'POST':
        nom = request.POST['nom']
        description = request.POST['description']
        date_debut = request.POST['date_debut']
        date_fin = request.POST['date_fin']
        etat = request.POST['etat']
        chef = request.POST.get('chef_projet')
        # membres = request.POST.getlist('membres')
        # membres_{{ing.id}}
        chef_projet = Ingenieur.objects.get(pk=int(chef))
        
        
        projetCreer = Projet.objects.create(
            nom=nom,
            description=description,
            date_debut=date_debut,
            date_fin=date_fin,
            etat=etat,
            chef_projet=chef_projet,
        )
        # ingenieurSelectionner = []
        for ing in membres:
            membre = request.POST.get(f"membres_{ing.id}")
            if membre == None:
                continue
            else:
                # print("les id des ingenieurs sont : ",membre)
                ingenieurSele = Ingenieur.objects.get(pk=int(membre))
                if membre:
                    MembreProjet.objects.create(
                        projet = projetCreer,
                        membre = ingenieurSele
                    )
            
        
        # Traitement des données...
        
        return redirect('listeProjet')
    return render(request, 'creerProjet.html', {"Membres":membres})

def detail_projet(request, pk):
    projet = get_object_or_404(Projet, pk=pk)
    equipes = MembreProjet.objects.filter(projet__id = pk)
    return render(request, 'detailProjet.html', {'projet': projet, 'equipes': equipes})



def ListeProjetsView(LoginRequiredMixin, ListView):
    model = Projet
    template_name = 'list_projects.html'
    context_object_name = 'projets'

def DetailProjetView(LoginRequiredMixin, DetailView):
    model = Projet
    template_name = 'project_detail.html'


def ajouter_ingenieur_projet(request, pk):
    projet = get_object_or_404(Projet, pk=pk)
    if request.method == 'POST':
        form = IngenieurForm(request.POST)
        if form.is_valid():
            ingenieur = form.save(commit=False)
            ingenieur.user = request.user
            ingenieur.save()
            projet.ingenieurs.add(ingenieur)
            return redirect('detail_projet', pk=projet.pk)
    else:
        form = IngenieurForm()
    return render(request, 'add_engineer.html', {'form': form, 'projet': projet})

def detailIngenieur(request, id):
    ingenieur = get_object_or_404(Ingenieur, id=id)
    return render(request, 'detailIngenieur.html', {'ingenieur': ingenieur})



def supprimerProjet(request, id):
    projet = get_object_or_404(Projet, id=id)
    projet.delete()
    return redirect('listeProjet')



def modifyProjet(request, id):
    projet = get_object_or_404(Projet, id=id)
    if request.method == 'POST':
        form = ProjetForm(request.POST, instance=projet)
        if form.is_valid():
            form.save()
            return redirect('listeProjet')
    else:
        form = ProjetForm(instance=projet)
    return render(request, 'modify_projet.html', {'form': form, 'projet': projet})








