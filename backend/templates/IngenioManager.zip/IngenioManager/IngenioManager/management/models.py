from django.db import models


# Create your models here.

class Categorie(models.Model):
    libeller = models.CharField(default=100)

    def __str__(self):
        return self.libeller

class Ingenieur(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    age = models.IntegerField()
    niveaux_experience = models.CharField(max_length=255)
    email = models.EmailField()
    telephone = models.CharField(max_length=15)
    categorie = models.ForeignKey(Categorie, on_delete=models.CASCADE, related_name='ingenieurs')
    dteNaissance = models.DateField()
    def __str__(self):
        return f"{self.prenom} {self.nom}"

class Utilisateur(models.Model):
    nom = models.CharField(max_length=50)  
    mot_de_passe = models.CharField(max_length=50)


class Projet(models.Model):
    ETAT_CHOICES = [
        ('PL', 'Planification'),
        ('EC', 'En cours'),
        ('TE', 'Terminé'),
        ('AN', 'Annulé'),
    ]

    nom = models.CharField(max_length=200)
    description = models.TextField()
    date_debut = models.DateField()
    date_fin = models.DateField()
    etat = models.CharField(max_length=2, choices=ETAT_CHOICES, default='PL')
    chef_projet = models.ForeignKey(Ingenieur, on_delete=models.SET_NULL, null=True, related_name='projets_diriges')
    
    def _str_(self):
        return self.nom


class MembreProjet(models.Model):
    projet = models.ForeignKey(Projet, on_delete=models.CASCADE, related_name='membres')
    membre = models.ForeignKey(Ingenieur, on_delete=models.CASCADE, related_name='projets')

    